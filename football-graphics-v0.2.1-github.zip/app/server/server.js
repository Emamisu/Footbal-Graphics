const express = require('express');
const http = require('http');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PERIOD_MS = {
  FIRST_HALF: 45 * 60 * 1000,
  SECOND_HALF: 90 * 60 * 1000,
  EXTRA_FIRST: 105 * 60 * 1000,
  EXTRA_SECOND: 120 * 60 * 1000
};

const DEFAULT_STATE = {
  match: {
    home: { name: 'MILAN', score: 0, logo: '' },
    away: { name: 'INTER', score: 0, logo: '' },
    period: 1,
    phase: 'FIRST_HALF',
    clockMs: 0,
    running: false,
    status: 'READY',
    competition: '',
    round: '',
    date: '',
    venue: '',
    commentator: ''
  },
  visible: { scorebug: true, goal: false, card: false, lowerThird: false, rosters: false, summary: false },
  rosters: { home: [], away: [] },
  durations: { goal: 5000, card: 5000, substitution: 5000, lowerThird: 5000 },
  lastEvent: null,
  events: []
};

function dataDir() {
  const base = process.env.FOOTBALL_GRAPHICS_DATA || path.join(os.homedir(), '.football-graphics');
  fs.mkdirSync(base, { recursive: true });
  return base;
}

function dataPath() {
  return path.join(dataDir(), 'state.json');
}

function teamsDir() {
  const dir = path.join(dataDir(), 'teams');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function loadState() {
  try {
    const loaded = JSON.parse(fs.readFileSync(dataPath(), 'utf8'));
    return {
      ...structuredClone(DEFAULT_STATE),
      ...loaded,
      match: { ...structuredClone(DEFAULT_STATE.match), ...(loaded.match || {}) },
      visible: { ...structuredClone(DEFAULT_STATE.visible), ...(loaded.visible || {}) },
      rosters: { ...structuredClone(DEFAULT_STATE.rosters), ...(loaded.rosters || {}) },
      durations: { ...structuredClone(DEFAULT_STATE.durations), ...(loaded.durations || {}) },
      events: Array.isArray(loaded.events) ? loaded.events : [],
      lastEvent: loaded.lastEvent || null
    };
  } catch {
    return structuredClone(DEFAULT_STATE);
  }
}

function saveState(state) {
  fs.writeFileSync(dataPath(), JSON.stringify(state, null, 2));
}

function localAddresses(port) {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const n of list || []) {
      if (n.family === 'IPv4' && !n.internal) out.push(`http://${n.address}:${port}`);
    }
  }
  return out;
}

function normalizeSide(side) {
  return side === 'away' ? 'away' : 'home';
}

function eventId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}


function csvEscape(value) {
  const s = value == null ? '' : String(value);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function parseCsv(text) {
  const rows = [];
  let row = [], field = '', quoted = false;
  const input = String(text || '').replace(/^\uFEFF/, '');
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (quoted) {
      if (ch === '"') {
        if (input[i + 1] === '"') { field += '"'; i++; }
        else quoted = false;
      } else field += ch;
    } else if (ch === '"' && field === '') {
      quoted = true;
    } else if (ch === ',') {
      row.push(field); field = '';
    } else if (ch === '\n') {
      row.push(field); field = '';
      if (row.some(v => v !== '')) rows.push(row);
      row = [];
    } else if (ch !== '\r') {
      field += ch;
    }
  }
  if (quoted) throw new Error('CSV non valido: virgolette non chiuse.');
  if (field !== '' || row.length) {
    row.push(field);
    if (row.some(v => v !== '')) rows.push(row);
  }
  if (!rows.length) throw new Error('CSV vuoto.');
  const headers = rows.shift().map(h => h.trim().toLowerCase());
  const required = ['tipo', 'chiave', 'valore', 'squadra', 'numero', 'giocatore', 'ruolo', 'stato', 'logo'];
  if (headers.length !== required.length || !required.every((h, i) => headers[i] === h)) {
    throw new Error(`Intestazione CSV non valida. Attesa: ${required.join(',')}`);
  }
  return rows.map(r => Object.fromEntries(required.map((h, i) => [h, String(r[i] ?? '').trim()])));
}

function buildMatchCsv(state) {
  const rows = [['tipo','chiave','valore','squadra','numero','giocatore','ruolo','stato','logo']];
  const match = state.match;
  for (const [key, value] of [
    ['competizione', match.competition],
    ['giornata', match.round],
    ['data', match.date],
    ['stadio', match.venue],
    ['telecronista', match.commentator]
  ]) rows.push(['MATCH', key, value || '', '', '', '', '', '', '']);
  for (const side of ['home', 'away']) {
    rows.push(['TEAM', 'nome', match[side].name || '', side, '', '', '', '', match[side].logo || '']);
    for (const player of state.rosters[side] || []) {
      rows.push(['PLAYER', '', '', side, player.number || '', player.name || '', player.role || '', player.starter ? 'Titolare' : 'Panchina', '']);
    }
  }
  return '\uFEFF' + rows.map(row => row.map(csvEscape).join(',')).join('\r\n') + '\r\n';
}

function applyCsvConfig(state, rows) {
  const next = { match: {}, rosters: { home: [], away: [] } };
  for (const row of rows) {
    const type = row.tipo.toUpperCase();
    if (type === 'MATCH') {
      const map = { competizione: 'competition', giornata: 'round', data: 'date', stadio: 'venue', telecronista: 'commentator' };
      const key = map[row.chiave.toLowerCase()];
      if (key) next.match[key] = row.valore.slice(0, 80);
    } else if (type === 'TEAM') {
      if (!['home', 'away'].includes(row.squadra.toLowerCase())) throw new Error(`Squadra non valida: ${row.squadra}`);
      const side = row.squadra.toLowerCase();
      if (row.chiave.toLowerCase() === 'nome') next.match[`${side}Name`] = row.valore.slice(0, 32).trim().toUpperCase();
      if (row.logo) next.match[`${side}Logo`] = row.logo;
    } else if (type === 'PLAYER') {
      if (!['home', 'away'].includes(row.squadra.toLowerCase())) throw new Error(`Squadra non valida: ${row.squadra}`);
      const side = row.squadra.toLowerCase();
      if (!row.giocatore) continue;
      next.rosters[side].push({
        number: row.numero.slice(0, 3),
        name: row.giocatore.slice(0, 48),
        role: row.ruolo.slice(0, 16),
        starter: row.stato.toLowerCase() === 'titolare'
      });
    }
  }
  if (!next.match.homeName && !next.match.awayName && !next.match.competition && !next.rosters.home.length && !next.rosters.away.length) {
    throw new Error('Il CSV non contiene dati riconoscibili.');
  }
  next.rosters.hasRows = { home: rows.some(r => r.tipo.toUpperCase() === 'PLAYER' && r.squadra.toLowerCase() === 'home'), away: rows.some(r => r.tipo.toUpperCase() === 'PLAYER' && r.squadra.toLowerCase() === 'away') };
  return next;
}

async function startServer({ port = Number(process.env.PORT) || 9876 } = {}) {
  const app = express();
  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const state = loadState();
  let lastTick = Date.now();

  app.use(express.json({ limit: '12mb' }));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  app.get('/', (_, res) => res.redirect('/control'));
  app.get('/control', (_, res) => res.sendFile(path.join(__dirname, '..', 'public', 'control.html')));
  app.get('/setup', (_, res) => res.sendFile(path.join(__dirname, '..', 'public', 'setup.html')));
  app.get('/output', (_, res) => res.sendFile(path.join(__dirname, '..', 'public', 'output.html')));
  app.get('/api/state', (_, res) => res.json(state));
  app.get('/api/server', (_, res) => res.json({ name: os.hostname(), port, urls: localAddresses(port) }));
  app.use('/team-assets', express.static(teamsDir(), { fallthrough: false }));

  function broadcast() {
    const payload = JSON.stringify({ type: 'STATE', state });
    for (const client of wss.clients) if (client.readyState === 1) client.send(payload);
  }

  function mutate(fn) {
    fn(state);
    saveState(state);
    broadcast();
  }

  function tick() {
    const now = Date.now();
    if (state.match.running) state.match.clockMs += now - lastTick;
    lastTick = now;
  }

  function addEvent(event) {
    state.events.unshift(event);
    state.events = state.events.slice(0, 100);
    state.lastEvent = event;
  }

  function saveTeamLogo(side, dataUrl) {
    if (!dataUrl) return '';

    const match = String(dataUrl).match(/^data:image\/(png|jpeg|jpg|webp);base64,(.+)$/i);
    if (!match) throw new Error('Logo non valido: usare PNG, JPEG o WEBP.');

    const ext = match[1].toLowerCase() === 'jpeg' || match[1].toLowerCase() === 'jpg' ? 'jpg' : match[1].toLowerCase();
    const filename = `${side}.${ext}`;
    const target = path.join(teamsDir(), filename);
    fs.writeFileSync(target, Buffer.from(match[2], 'base64'));

    for (const other of ['png', 'jpg', 'webp']) {
      if (`${side}.${other}` !== filename) {
        const old = path.join(teamsDir(), `${side}.${other}`);
        if (fs.existsSync(old)) fs.unlinkSync(old);
      }
    }

    return `/team-assets/${filename}?v=${Date.now()}`;
  }

  app.post('/api/rosters', (req, res) => {
    mutate(s => {
      for (const side of ['home', 'away']) {
        if (!Array.isArray(req.body[side])) continue;
        s.rosters[side] = req.body[side].map((player, index) => ({
          id: String(player.id || `${side}-${index + 1}-${Date.now()}`),
          number: String(player.number ?? '').slice(0, 3),
          name: String(player.name ?? '').slice(0, 48).trim(),
          role: String(player.role ?? '').slice(0, 16).trim(),
          starter: !!player.starter
        })).filter(player => player.name);
      }
    });
    res.json(state);
  });

  app.post('/api/setup', (req, res) => {
    try {
      mutate(s => {
        if (req.body.homeName != null) {
          s.match.home.name = String(req.body.homeName).slice(0, 32).trim().toUpperCase() || 'CASA';
        }
        if (req.body.awayName != null) {
          s.match.away.name = String(req.body.awayName).slice(0, 32).trim().toUpperCase() || 'OSPITE';
        }
        for (const key of ['competition', 'round', 'date', 'venue', 'commentator']) {
          if (req.body[key] != null) s.match[key] = String(req.body[key]).slice(0, 80).trim();
        }

        for (const side of ['home', 'away']) {
          if (Array.isArray(req.body[side])) {
            s.rosters[side] = req.body[side].map((player, index) => ({
              id: String(player.id || `${side}-${index + 1}-${Date.now()}`),
              number: String(player.number ?? '').slice(0, 3),
              name: String(player.name ?? '').slice(0, 48).trim(),
              role: String(player.role ?? '').slice(0, 16).trim(),
              starter: !!player.starter
            })).filter(player => player.name);
          }
        }

        if (req.body.durations && typeof req.body.durations === 'object') {
          for (const key of ['goal', 'card', 'substitution', 'lowerThird']) {
            if (req.body.durations[key] != null) {
              const value = Math.floor(Number(req.body.durations[key]));
              if (Number.isFinite(value)) {
                s.durations[key] = Math.min(60000, Math.max(250, value));
              }
            }
          }
        }

        if (req.body.homeLogo === null) s.match.home.logo = '';
        else if (typeof req.body.homeLogo === 'string' && req.body.homeLogo.startsWith('data:image/')) {
          s.match.home.logo = saveTeamLogo('home', req.body.homeLogo);
        }

        if (req.body.awayLogo === null) s.match.away.logo = '';
        else if (typeof req.body.awayLogo === 'string' && req.body.awayLogo.startsWith('data:image/')) {
          s.match.away.logo = saveTeamLogo('away', req.body.awayLogo);
        }
      });

      res.json(state);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });


  app.get('/api/setup/export-csv', (_, res) => {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="football-match-config.csv"');
    res.send(buildMatchCsv(state));
  });

  app.post('/api/setup/import-csv', express.text({ type: ['text/csv', 'text/plain'], limit: '2mb' }), (req, res) => {
    try {
      const config = applyCsvConfig(state, parseCsv(req.body));
      mutate(s => {
        for (const key of ['competition', 'round', 'date', 'venue', 'commentator']) {
          if (config.match[key] !== undefined) s.match[key] = config.match[key];
        }
        for (const side of ['home', 'away']) {
          if (config.match[`${side}Name`] !== undefined) s.match[side].name = config.match[`${side}Name`];
          if (config.match[`${side}Logo`] !== undefined) s.match[side].logo = config.match[`${side}Logo`];
          if (config.rosters.hasRows[side]) s.rosters[side] = config.rosters[side].map((player, index) => ({
            id: `${side}-csv-${index + 1}-${Date.now()}`,
            ...player
          }));
        }
      });
      res.json({ ok: true, state });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  wss.on('connection', ws => {
    ws.send(JSON.stringify({ type: 'STATE', state }));
  });

  app.post('/api/match', (req, res) => {
    mutate(s => {
      if (req.body.home != null) s.match.home.name = String(req.body.home).slice(0, 32).toUpperCase();
      if (req.body.away != null) s.match.away.name = String(req.body.away).slice(0, 32).toUpperCase();
    });
    res.json(state);
  });

  app.post('/api/match/start', (_, res) => {
    tick();
    mutate(s => {
      if (s.match.phase === 'FULL_TIME') return;
      s.match.running = true;
      s.match.status = 'LIVE';
    });
    res.json(state);
  });

  app.post('/api/match/pause', (_, res) => {
    tick();
    mutate(s => {
      s.match.running = false;
      s.match.status = 'PAUSED';
    });
    res.json(state);
  });

  app.post('/api/match/new', (_, res) => {
    mutate(s => {
      s.match.home.score = 0;
      s.match.away.score = 0;
      s.match.period = 1;
      s.match.phase = 'FIRST_HALF';
      s.match.clockMs = 0;
      s.match.running = false;
      s.match.status = 'READY';
      s.visible.goal = false;
      s.visible.card = false;
      s.visible.rosters = false;
      s.visible.summary = false;
      s.lastEvent = null;
      s.events = [];
    });
    res.json(state);
  });

  app.post('/api/match/reset', (_, res) => {
    mutate(s => {
      s.match.clockMs = 0;
      s.match.period = 1;
      s.match.phase = 'FIRST_HALF';
      s.match.running = false;
      s.match.status = 'READY';
      s.match.home.score = 0;
      s.match.away.score = 0;
      s.visible.goal = false;
      s.visible.card = false;
      s.lastEvent = null;
      s.events = [];
    });
    res.json(state);
  });

  app.post('/api/match/next-period', (_, res) => {
    tick();
    mutate(s => {
      s.match.running = false;
      if (s.match.phase === 'FIRST_HALF') {
        s.match.phase = 'SECOND_HALF'; s.match.period = 2; s.match.clockMs = Math.max(s.match.clockMs, PERIOD_MS.FIRST_HALF); s.match.status = 'INTERVAL';
      } else if (s.match.phase === 'SECOND_HALF') {
        s.match.phase = 'EXTRA_FIRST'; s.match.period = 3; s.match.clockMs = Math.max(s.match.clockMs, PERIOD_MS.SECOND_HALF); s.match.status = 'EXTRA TIME';
      } else if (s.match.phase === 'EXTRA_FIRST') {
        s.match.phase = 'EXTRA_SECOND'; s.match.period = 4; s.match.clockMs = Math.max(s.match.clockMs, PERIOD_MS.EXTRA_FIRST); s.match.status = 'EXTRA TIME';
      } else if (s.match.phase === 'EXTRA_SECOND') {
        s.match.phase = 'FULL_TIME'; s.match.period = 4; s.match.clockMs = Math.max(s.match.clockMs, PERIOD_MS.EXTRA_SECOND); s.match.status = 'FULL TIME';
      }
    });
    res.json(state);
  });

  app.post('/api/score', (req, res) => {
    mutate(s => {
      const side = normalizeSide(req.body.side);
      const delta = Number(req.body.delta) || 0;
      s.match[side].score = Math.max(0, s.match[side].score + delta);
      addEvent({ id: eventId(), type: 'SCORE', side, delta, minute: Math.floor(s.match.clockMs / 60000), at: Date.now() });
    });
    res.json(state);
  });

  app.post('/api/goal', (req, res) => {
    mutate(s => {
      const side = normalizeSide(req.body.side);
      s.match[side].score++;
      const event = {
        id: eventId(), type: 'GOAL', side,
        minute: Math.floor(s.match.clockMs / 60000),
        scoreHome: s.match.home.score, scoreAway: s.match.away.score,
        at: Date.now()
      };
      addEvent(event);
      s.visible.goal = true;
    });
    res.json(state);
  });

  app.post('/api/card', (req, res) => {
    mutate(s => {
      const side = normalizeSide(req.body.side);
      const card = ['YELLOW', 'SECOND_YELLOW', 'RED'].includes(req.body.card) ? req.body.card : 'YELLOW';
      const player = String(req.body.player || 'GIOCATORE').slice(0, 32);
      const number = String(req.body.number || '').slice(0, 3);
      const minute = Number.isFinite(Number(req.body.minute)) ? Math.max(0, Math.floor(Number(req.body.minute))) : Math.floor(s.match.clockMs / 60000);
      const event = { id: eventId(), type: 'CARD', card, side, player, number, minute, at: Date.now() };
      addEvent(event);
      s.visible.card = true;
    });
    res.json(state);
  });

  app.post('/api/substitution', (req, res) => {
    mutate(s => {
      const side = normalizeSide(req.body.side);
      const playerOut = String(req.body.playerOut || 'GIOCATORE').slice(0, 32);
      const numberOut = String(req.body.numberOut || '').slice(0, 3);
      const playerIn = String(req.body.playerIn || 'GIOCATORE').slice(0, 32);
      const numberIn = String(req.body.numberIn || '').slice(0, 3);
      const minute = Number.isFinite(Number(req.body.minute))
        ? Math.max(0, Math.floor(Number(req.body.minute)))
        : Math.floor(s.match.clockMs / 60000);
      addEvent({
        id: eventId(),
        type: 'SUBSTITUTION',
        side,
        playerOut, numberOut,
        playerIn, numberIn,
        minute,
        at: Date.now()
      });
    });
    res.json(state);
  });

  app.post('/api/events/delete', (req, res) => {
    const id = String(req.body.id || '');
    const index = state.events.findIndex(event => event.id === id);
    if (index < 0) return res.status(404).json({ error: 'Evento non trovato' });

    const event = state.events[index];
    mutate(s => {
      if (event.type === 'GOAL') {
        s.match[event.side].score = Math.max(0, s.match[event.side].score - 1);
      } else if (event.type === 'SCORE') {
        const delta = Number(event.delta || 0);
        s.match[event.side].score = Math.max(0, s.match[event.side].score - delta);
      }
      s.events.splice(index, 1);
      s.lastEvent = s.events[0] || null;
      if (event.type === 'GOAL') s.visible.goal = false;
      if (event.type === 'CARD') s.visible.card = false;
    });
    res.json(state);
  });

  app.post('/api/graphics', (req, res) => {
    mutate(s => {
      for (const key of ['scorebug', 'goal', 'card', 'lowerThird', 'rosters', 'summary']) {
        if (typeof req.body[key] === 'boolean') s.visible[key] = req.body[key];
      }
    });
    res.json(state);
  });

  const timer = setInterval(() => {
    tick();
    if (state.match.running) { saveState(state); broadcast(); }
  }, 250);

  await new Promise((resolve, reject) => {
    httpServer.once('error', reject);
    httpServer.listen(port, '0.0.0.0', resolve);
  });

  return { port, close: () => new Promise(resolve => { clearInterval(timer); httpServer.close(resolve); }) };
}

module.exports = { startServer };

if (require.main === module) {
  startServer()
    .then(({ port }) => {
      console.log(`Football Graphics server listening on port ${port}`);
      console.log(`Local: http://localhost:${port}`);
    })
    .catch(err => {
      console.error('Failed to start server:', err);
      process.exit(1);
    });
}

# Football Graphics v0.2.1

Server desktop per Mac/Windows con controllo da browser LAN e output trasparente per OBS.

## Avvio sviluppo

```bash
npm install
npm run dev
```

Il server usa la porta `9876` e ascolta sulla LAN. Dal browser di un altro dispositivo aprire `http://IP_DEL_SERVER:9876/control`.

Per avviare l'app Electron:

```bash
npm start
```

## OBS

Aggiungere una Browser Source:

`http://IP_DEL_SERVER:9876/output`

Dimensione: 1920x1080. La pagina ha sfondo trasparente.

## Configurazione partita CSV

In `SETUP PARTITA` sono disponibili `IMPORTA CSV` ed `ESPORTA CSV`.

Il CSV contiene competizione, giornata, data, stadio, telecronista, squadre, loghi (come riferimento al percorso del server) e rose con numero, ruolo e stato Titolare/Panchina. È UTF-8 con BOM ed è pensato per essere modificabile con Excel, Numbers o LibreOffice.

Il CSV è un formato di scambio/configurazione; lo stato operativo dell'applicazione resta nel file di stato interno. L'importazione della configurazione non modifica punteggio, timer o storico eventi.

## Build

```bash
npm run dist
```

Su macOS genera DMG/ZIP; su Windows genera NSIS installer, usando electron-builder sulla piattaforma di build.

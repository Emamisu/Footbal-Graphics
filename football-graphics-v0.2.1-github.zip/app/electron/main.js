const { app, BrowserWindow, dialog } = require('electron');
const path = require('path');
const { startServer } = require(path.join(__dirname, '..', 'server', 'server.js'));

let server;
let win;

async function createWindow() {
  server = await startServer();
  win = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 900,
    minHeight: 650,
    webPreferences: { contextIsolation: true, nodeIntegration: false }
  });
  await win.loadURL(`http://127.0.0.1:${server.port}/control`);
  win.on('closed', () => { win = null; });
}

app.whenReady().then(createWindow).catch(err => {
  dialog.showErrorBox('Football Graphics', err.stack || String(err));
  app.quit();
});

app.on('window-all-closed', () => app.quit());
app.on('before-quit', async () => { if (server?.close) await server.close(); });

const $ = id => document.getElementById(id);
let state = null;
let homeLogoData = undefined;
let awayLogoData = undefined;
let rosters = { home: [], away: [] };

function readImage(file, previewId, side) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    if (side === 'home') homeLogoData = reader.result; else awayLogoData = reader.result;
    $(previewId).src = reader.result;
    updatePreview();
  };
  reader.readAsDataURL(file);
}

function updatePreview() {
  $('previewHomeName').textContent = $('homeName').value.toUpperCase() || 'CASA';
  $('previewAwayName').textContent = $('awayName').value.toUpperCase() || 'OSPITE';
  $('previewHomeLogo').src = $('homePreview').src || '';
  $('previewAwayLogo').src = $('awayPreview').src || '';
  $('rosterHomeTitle').textContent = $('homeName').value.toUpperCase() || 'CASA';
  $('rosterAwayTitle').textContent = $('awayName').value.toUpperCase() || 'OSPITE';
}

function renderRoster(side) {
  const host = $(side === 'home' ? 'homeRoster' : 'awayRoster');
  host.innerHTML = '';
  rosters[side].forEach((player, i) => {
    const row = document.createElement('div');
    row.className = 'roster-row';
    row.innerHTML = `<input type="text" maxlength="3" placeholder="N°" value="${esc(player.number)}">` +
      `<input type="text" maxlength="48" placeholder="Giocatore" value="${esc(player.name)}">` +
      `<input type="text" maxlength="16" placeholder="Ruolo" value="${esc(player.role)}">` +
      `<select title="Stato giocatore"><option value="starter" ${player.starter ? 'selected' : ''}>Titolare</option><option value="bench" ${player.starter ? '' : 'selected'}>Panchina</option></select>` +
      `<button type="button" title="Rimuovi">×</button>`;
    const inputs = row.querySelectorAll('input');
    inputs[0].oninput = e => player.number = e.target.value;
    inputs[1].oninput = e => player.name = e.target.value;
    inputs[2].oninput = e => player.role = e.target.value;
    row.querySelector('select').onchange = e => player.starter = e.target.value === 'starter';
    row.querySelector('button').onclick = () => { rosters[side].splice(i, 1); renderRoster(side); };
    host.appendChild(row);
  });
}

function esc(v) {
  return String(v || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function render(s) {
  state = s;
  rosters = {
    home: Array.isArray(s.rosters?.home) ? structuredClone(s.rosters.home) : [],
    away: Array.isArray(s.rosters?.away) ? structuredClone(s.rosters.away) : []
  };
  $('homeName').value = s.match.home.name || '';
  $('awayName').value = s.match.away.name || '';
  $('competition').value = s.match.competition || '';
  $('round').value = s.match.round || '';
  $('matchDate').value = s.match.date || '';
  $('venue').value = s.match.venue || '';
  $('commentator').value = s.match.commentator || '';
  if (s.match.home.logo) $('homePreview').src = s.match.home.logo; else $('homePreview').removeAttribute('src');
  if (s.match.away.logo) $('awayPreview').src = s.match.away.logo; else $('awayPreview').removeAttribute('src');
  const d = s.durations || {};
  $('goalDuration').value = d.goal ?? 5000;
  $('cardDuration').value = d.card ?? 5000;
  $('substitutionDuration').value = d.substitution ?? 5000;
  $('lowerThirdDuration').value = d.lowerThird ?? 5000;
  renderRoster('home');
  renderRoster('away');
  updatePreview();
}

async function save() {
  const payload = {
    homeName: $('homeName').value,
    awayName: $('awayName').value,
    competition: $('competition').value,
    round: $('round').value,
    date: $('matchDate').value,
    venue: $('venue').value,
    commentator: $('commentator').value,
    durations: {
      goal: Number($('goalDuration').value),
      card: Number($('cardDuration').value),
      substitution: Number($('substitutionDuration').value),
      lowerThird: Number($('lowerThirdDuration').value)
    },
    home: rosters.home,
    away: rosters.away
  };
  if (homeLogoData !== undefined) payload.homeLogo = homeLogoData;
  if (awayLogoData !== undefined) payload.awayLogo = awayLogoData;
  $('status').textContent = 'Salvataggio...';
  try {
    const r = await fetch('/api/setup', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    const result = await r.json();
    if (!r.ok) throw new Error(result.error || `HTTP ${r.status}`);
    homeLogoData = undefined;
    awayLogoData = undefined;
    $('status').textContent = 'Configurazione salvata';
    render(result);
  } catch (e) {
    console.error(e);
    $('status').textContent = `Errore: ${e.message}`;
  }
}

async function exportCsv() {
  $('status').textContent = 'Esportazione CSV...';
  try {
    const r = await fetch('/api/setup/export-csv');
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'football-match-config.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    $('status').textContent = 'CSV esportato';
  } catch (e) {
    $('status').textContent = `Errore export: ${e.message}`;
  }
}

function importCsvFile(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async () => {
    $('status').textContent = 'Importazione CSV...';
    try {
      const r = await fetch('/api/setup/import-csv', {
        method:'POST',
        headers:{'Content-Type':'text/csv; charset=utf-8'},
        body:reader.result
      });
      const result = await r.json();
      if (!r.ok) throw new Error(result.error || `HTTP ${r.status}`);
      homeLogoData = undefined;
      awayLogoData = undefined;
      $('status').textContent = 'CSV importato';
      render(result.state);
    } catch (e) {
      console.error(e);
      $('status').textContent = `Errore import: ${e.message}`;
    }
  };
  reader.readAsText(file, 'UTF-8');
}

$('homeLogo').addEventListener('change', e => readImage(e.target.files[0], 'homePreview', 'home'));
$('awayLogo').addEventListener('change', e => readImage(e.target.files[0], 'awayPreview', 'away'));
$('homeName').addEventListener('input', updatePreview);
$('awayName').addEventListener('input', updatePreview);
$('save').addEventListener('click', save);
$('exportCsv').addEventListener('click', exportCsv);
$('importCsv').addEventListener('click', () => $('csvFile').click());
$('csvFile').addEventListener('change', e => { importCsvFile(e.target.files[0]); e.target.value = ''; });
$('addHomePlayer').onclick = () => { rosters.home.push({number:'',name:'',role:'',starter:false}); renderRoster('home'); };
$('addAwayPlayer').onclick = () => { rosters.away.push({number:'',name:'',role:'',starter:false}); renderRoster('away'); };
$('homeClear').onclick = () => { homeLogoData = null; $('homePreview').removeAttribute('src'); $('homeLogo').value = ''; updatePreview(); };
$('awayClear').onclick = () => { awayLogoData = null; $('awayPreview').removeAttribute('src'); $('awayLogo').value = ''; updatePreview(); };
fetch('/api/state').then(r => r.json()).then(render).catch(console.error);

const $ = id => document.getElementById(id);

let goalAnimation = null;
let cardAnimation = null;
let goalHideTimer = null;
let cardHideTimer = null;
let lastGoalEventId = null;
let lastCardEventId = null;
let substitutionAnimation = null;
let substitutionHideTimer = null;
let lastSubstitutionEventId = null;
let currentDurations = { goal: 5000, card: 5000, substitution: 5000, lowerThird: 5000 };

function formatTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function fitStage() {
  const stage = $('stage');
  if (!stage) return;
  const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
  stage.style.setProperty('--scale', scale);
}

function periodLabel(match) {
  switch (match.phase) {
    case 'FIRST_HALF': return '1° TEMPO';
    case 'SECOND_HALF': return '2° TEMPO';
    case 'EXTRA_FIRST': return '1° SUPPLEMENTARE';
    case 'EXTRA_SECOND': return '2° SUPPLEMENTARE';
    case 'FULL_TIME': return 'FINE PARTITA';
    default: return `${match.period || 1}° TEMPO`;
  }
}

function isRecovery(match) {
  const minutes = match.clockMs / 60000;
  const limits = { FIRST_HALF: 45, SECOND_HALF: 90, EXTRA_FIRST: 105, EXTRA_SECOND: 120 };
  return limits[match.phase] != null && minutes >= limits[match.phase];
}

function setLogo(id, logo) {
  const img = $(id);
  if (!img) return;
  if (logo) {
    img.src = logo;
    img.style.display = 'block';
  } else {
    img.removeAttribute('src');
    img.style.display = 'none';
  }
}

function hideGoal() {
  const goal = $('goal');
  if (!goal) return;
  clearTimeout(goalHideTimer);
  if (goalAnimation) {
    goalAnimation.cancel();
    goalAnimation = null;
  }
  goal.classList.add('hidden');
  goal.style.opacity = '';
  goal.style.transform = '';
}

function animateGoal(durationMs = currentDurations.goal) {
  const goal = $('goal');
  if (!goal) return;

  clearTimeout(goalHideTimer);
  if (goalAnimation) goalAnimation.cancel();

  goal.classList.remove('hidden');

  goalAnimation = goal.animate([
    { opacity: 0, transform: 'translate(-50%, -50%) scale(0.65)' },
    { opacity: 1, transform: 'translate(-50%, -50%) scale(1.06)', offset: 0.65 },
    { opacity: 1, transform: 'translate(-50%, -50%) scale(1)' }
  ], {
    duration: 550,
    easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
    fill: 'forwards'
  });

  goalAnimation.onfinish = () => {
    goalAnimation = null;
    goalHideTimer = setTimeout(() => {
      if (goalAnimation) goalAnimation.cancel();
      goalAnimation = goal.animate([
        { opacity: 1, transform: 'translate(-50%, -50%) scale(1)' },
        { opacity: 0.75, transform: 'translate(-50%, -50%) scale(1.35)', offset: 0.35 },
        { opacity: 0.30, transform: 'translate(-50%, -50%) scale(1.75)', offset: 0.70 },
        { opacity: 0, transform: 'translate(-50%, -50%) scale(2.20)' }
      ], {
        duration: 900,
        easing: 'cubic-bezier(0.22, 0.61, 0.36, 1)',
        fill: 'forwards'
      });
      goalAnimation.onfinish = () => {
        goalAnimation = null;
        goal.classList.add('hidden');
        goal.style.opacity = '';
        goal.style.transform = '';
      };
    }, Math.max(250, Number(durationMs) || 5000));
  };
}

function renderGoal(state) {
  const goal = $('goal');
  if (!goal) return;
  const event = state.lastEvent;

  if (event && event.type === 'GOAL' && event.id !== lastGoalEventId) {
    lastGoalEventId = event.id;
    const side = event.side === 'away' ? 'away' : 'home';
    const team = side === 'home' ? state.match.home : state.match.away;
    $('goalTeam').textContent = team.name;
    $('goalScore').textContent = `${event.scoreHome ?? state.match.home.score} — ${event.scoreAway ?? state.match.away.score}`;
    hideSubstitution();
    animateGoal(currentDurations.goal);
  }
}

function hideCard() {
  const card = $('card');
  if (!card) return;
  clearTimeout(cardHideTimer);
  if (cardAnimation) {
    cardAnimation.cancel();
    cardAnimation = null;
  }
  card.classList.add('hidden');
  card.style.opacity = '';
  card.style.transform = '';
}

function animateCard(durationMs = currentDurations.card) {
  const card = $('card');
  if (!card) return;

  clearTimeout(cardHideTimer);
  if (cardAnimation) cardAnimation.cancel();

  card.classList.remove('hidden');

  cardAnimation = card.animate([
    { opacity: 0, transform: 'translateX(120px) scale(0.75)' },
    { opacity: 1, transform: 'translateX(-8px) scale(1.04)', offset: 0.65 },
    { opacity: 1, transform: 'translateX(0) scale(1)' }
  ], {
    duration: 450,
    easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
    fill: 'forwards'
  });

  cardAnimation.onfinish = () => {
    cardAnimation = null;
    cardHideTimer = setTimeout(() => {
      cardAnimation = card.animate([
        { opacity: 1, transform: 'translateX(0) scale(1)' },
        { opacity: 0, transform: 'translateX(100px) scale(0.92)' }
      ], {
        duration: 700,
        easing: 'cubic-bezier(0.22, 0.61, 0.36, 1)',
        fill: 'forwards'
      });
      cardAnimation.onfinish = () => {
        cardAnimation = null;
        card.classList.add('hidden');
        card.style.opacity = '';
        card.style.transform = '';
      };
    }, Math.max(250, Number(durationMs) || 5000));
  };
}

function renderCard(state) {
  const card = $('card');
  if (!card) return;
  const event = state.lastEvent;

  if (event && event.type === 'CARD' && event.id !== lastCardEventId) {
    lastCardEventId = event.id;

    const side = event.side === 'away' ? 'away' : 'home';
    const team = side === 'home' ? state.match.home : state.match.away;

    $('cardTeam').textContent = team.name;
    $('cardPlayer').textContent = event.player || 'GIOCATORE';

    const number = event.number ? `#${event.number}` : '';
    const minute = event.minute != null ? `${event.minute}'` : '';
    $('cardMeta').textContent = [number, minute].filter(Boolean).join(' · ');

    card.classList.remove('card-yellow', 'card-red', 'card-second-yellow');

    if (event.card === 'RED') {
      $('cardIcon').textContent = '🟥';
      card.classList.add('card-red');
    } else if (event.card === 'SECOND_YELLOW') {
      $('cardIcon').textContent = '🟨 🟥';
      card.classList.add('card-second-yellow');
    } else {
      $('cardIcon').textContent = '🟨';
      card.classList.add('card-yellow');
    }

    hideSubstitution();
    animateCard(currentDurations.card);
  }
}


function hideSubstitution() {
  const el = $('substitution');
  if (!el) return;
  clearTimeout(substitutionHideTimer);
  if (substitutionAnimation) {
    substitutionAnimation.cancel();
    substitutionAnimation = null;
  }
  el.classList.add('hidden');
  el.style.opacity = '';
  el.style.transform = '';
}

function animateSubstitution(durationMs = currentDurations.substitution) {
  const el = $('substitution');
  if (!el) return;

  clearTimeout(substitutionHideTimer);
  if (substitutionAnimation) substitutionAnimation.cancel();

  el.classList.remove('hidden');
  substitutionAnimation = el.animate([
    { opacity: 0, transform: 'translateX(-120px) scale(0.82)' },
    { opacity: 1, transform: 'translateX(8px) scale(1.03)', offset: 0.65 },
    { opacity: 1, transform: 'translateX(0) scale(1)' }
  ], {
    duration: 500,
    easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
    fill: 'forwards'
  });

  substitutionAnimation.onfinish = () => {
    substitutionAnimation = null;
    substitutionHideTimer = setTimeout(() => {
      substitutionAnimation = el.animate([
        { opacity: 1, transform: 'translateX(0) scale(1)' },
        { opacity: 0, transform: 'translateX(-80px) scale(0.96)' }
      ], {
        duration: 600,
        easing: 'cubic-bezier(0.22, 0.61, 0.36, 1)',
        fill: 'forwards'
      });
      substitutionAnimation.onfinish = () => {
        substitutionAnimation = null;
        el.classList.add('hidden');
        el.style.opacity = '';
        el.style.transform = '';
      };
    }, Math.max(250, Number(durationMs) || 5000));
  };
}

function renderSubstitution(state) {
  const el = $('substitution');
  if (!el) return;
  const event = state.lastEvent;

  if (event && event.type === 'SUBSTITUTION' && event.id !== lastSubstitutionEventId) {
    lastSubstitutionEventId = event.id;
    const side = event.side === 'away' ? 'away' : 'home';
    const team = side === 'home' ? state.match.home : state.match.away;

    $('substitutionTeam').textContent = team.name;
    $('playerOut').textContent = event.playerOut || 'GIOCATORE';
    $('numberOut').textContent = event.numberOut ? `#${event.numberOut}` : '';
    $('playerIn').textContent = event.playerIn || 'GIOCATORE';
    $('numberIn').textContent = event.numberIn ? `#${event.numberIn}` : '';
    $('substitutionMinute').textContent = `${event.minute ?? Math.floor(state.match.clockMs / 60000)}'`;

    hideGoal();
    hideCard();
    animateSubstitution(currentDurations.substitution);
  }
}

function renderRosters(state) {
  const wrap = $('rostersGraphic'); if (!wrap) return;
  const renderTeam = (side, listId, nameId, logoId) => {
    const team = state.match[side]; const list = state.rosters?.[side] || [];
    $(nameId).textContent = team.name; setLogo(logoId, team.logo);
    $(listId).innerHTML = list.map(p => `<div class="roster-player ${p.starter ? 'starter' : ''}"><span>${escapeHtml(p.number || '')}</span><span>${escapeHtml(p.name)}</span><span>${escapeHtml(p.role || '')}</span></div>`).join('') || '<div class="summary-empty">Nessun giocatore inserito</div>';
  };
  renderTeam('home','rosterHomeList','rosterHomeName','rosterHomeLogo'); renderTeam('away','rosterAwayList','rosterAwayName','rosterAwayLogo');
  wrap.classList.toggle('hidden', !state.visible.rosters);
}
function renderSummary(state) {
  const wrap = $('summaryGraphic'); if (!wrap) return;
  $('summaryScore').textContent = `${state.match.home.name} ${state.match.home.score} — ${state.match.away.score} ${state.match.away.name}`;
  const events = (state.events || []).filter(e => ['GOAL','CARD','SUBSTITUTION'].includes(e.type)).slice().reverse();
  $('summaryList').innerHTML = events.length ? events.map(e => {
    const team = e.side === 'home' ? state.match.home.name : state.match.away.name;
    const icon = e.type === 'GOAL' ? '⚽' : e.type === 'SUBSTITUTION' ? '🔄' : e.card === 'RED' ? '🟥' : e.card === 'SECOND_YELLOW' ? '🟨🟥' : '🟨';
    const text = e.type === 'GOAL' ? team : e.type === 'CARD' ? `${team} — ${e.player}${e.number ? ' #' + e.number : ''}` : `${team} — ${e.playerOut} → ${e.playerIn}`;
    return `<div class="summary-event"><span class="minute">${e.minute ?? ''}'</span><span class="icon">${icon}</span><span>${escapeHtml(text)}</span></div>`;
  }).join('') : '<div class="summary-empty">Nessun evento registrato</div>';
  wrap.classList.toggle('hidden', !state.visible.summary);
}
function escapeHtml(value) { return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

function render(state) {
  currentDurations = { ...currentDurations, ...(state.durations || {}) };

  const match = state.match;

  $('homeName').textContent = match.home.name;
  $('awayName').textContent = match.away.name;
  $('homeScore').textContent = match.home.score;
  $('awayScore').textContent = match.away.score;
  $('clock').textContent = formatTime(match.clockMs);
  $('period').textContent = periodLabel(match);
  $('recovery').textContent = isRecovery(match) ? 'RECUPERO' : '';

  $('scorebug').classList.toggle('hidden', !state.visible.scorebug);

  setLogo('homeLogo', match.home.logo);
  setLogo('awayLogo', match.away.logo);

  renderGoal(state);
  renderCard(state);
  renderSubstitution(state);
  renderRosters(state);
  renderSummary(state);
}

function connect() {
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const ws = new WebSocket(`${protocol}//${location.host}/ws`);

  ws.onopen = () => console.log('WebSocket connected');

  ws.onmessage = event => {
    try {
      const message = JSON.parse(event.data);
      if (message.type === 'STATE') render(message.state);
    } catch (error) {
      console.error('WebSocket message error:', error);
    }
  };

  ws.onclose = () => setTimeout(connect, 1000);
  ws.onerror = error => console.error('WebSocket error:', error);
}

window.addEventListener('resize', fitStage);
fitStage();
connect();

fetch('/api/state')
  .then(response => {
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  })
  .then(render)
  .catch(error => console.error('Errore caricamento stato:', error));
